# CodePage2Unicode
Convert strings from ASCII to Unicode and vice versa
